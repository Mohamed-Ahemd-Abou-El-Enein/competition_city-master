# Add python code in this file
from FileHandler import FileHandler

file_header = FileHandler()
cities = file_header.read_file('cities.csv', "cities")
points = file_header.read_file('points.csv', "points")

for point in points:
	point.check_point(cities)

file_header.write_file("output_points.csv", points)




