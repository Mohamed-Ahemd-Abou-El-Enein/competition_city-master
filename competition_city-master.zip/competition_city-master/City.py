class City:

	def __init__(self, name, top_left, bottom_right):
		self.name = name
		self.top_left = top_left
		self.bottom_right = bottom_right
		self.reoreder_point()

	def reoreder_point(self):
		if self.top_left > self.bottom_right:
			temp_point = self.top_left
			self.top_left = self.top_left
			self.top_left = temp_point

