import csv
from City import City
from Point import Point


class FileHandler:
	closest_point = []
	farthest_point = []
	out_header_str = ""

	def read_file(self, filename, object_type):
		object_kind = []
		with open(filename, "r") as file:
			reader = csv.reader(file)
			header = True
			first_city = True
			for row in reader:
				if header:
					header = False
					FileHandler.out_header_str = row
					continue
				else:
					if object_type == "cities":
						top_left = (int(row[1]), int(row[2]))
						bottom_right = (int(row[3]), int(row[4]))
						object_kind.append(City(row[0], top_left, bottom_right))

						if (tuple(FileHandler.closest_point) >= top_left) and (not first_city):
							FileHandler.closest_point = list(top_left)
						if (tuple(FileHandler.farthest_point) <= bottom_right)and (not first_city):
							FileHandler.farthest_point = list(bottom_right)

						if first_city:
							first_city = False
							FileHandler.closest_point = list(top_left)
							FileHandler.farthest_point = list(bottom_right)
					else:
						point = (int(row[1]), int(row[2]))
						if (point >= tuple(FileHandler.closest_point)) and (point <= tuple(FileHandler.farthest_point)):
							object_kind.append(Point(row[0], point, ""))
						else:
							object_kind.append(Point(row[0], point, "None"))
		return object_kind

	def write_file(self, filename, outputs):
		with open(filename, "w", newline="") as file:
			writer = csv.writer(file, delimiter=',', quoting=csv.QUOTE_NONNUMERIC)
			for row in outputs:
				line = [row.point_id, row.point[0], row.point[1], row.city]
				writer.writerow(line)
