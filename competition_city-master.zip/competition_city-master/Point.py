class Point:

	def __init__(self, point_id, point, city):
		self.point_id = point_id
		self.point = point
		self.city = city

	def check_point(self, cities):
		if self.city == "":
			for city in cities:
				x_check = False
				y_check = False
				if (self.point[0] >= city.top_left[0]) and (self.point[0] <= city.bottom_right[0]):
					x_check = True

				if (self.point[1] >= city.top_left[1]) and (self.point[1] <= city.bottom_right[1]):
					y_check = True

				if x_check and y_check:
					self.city = city.name
					return
		return
